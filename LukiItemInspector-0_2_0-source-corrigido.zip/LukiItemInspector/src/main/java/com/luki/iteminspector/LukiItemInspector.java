package com.luki.iteminspector;

import net.minecraftforge.fml.common.Mod;

@Mod(LukiItemInspector.MOD_ID)
public class LukiItemInspector {
    public static final String MOD_ID = "lukiiteminspector";

    public LukiItemInspector() {
        // Todo o código é client-only e registrado via @Mod.EventBusSubscriber(Dist.CLIENT),
        // evitando carregar classes de cliente em servidor dedicado.
    }
}
