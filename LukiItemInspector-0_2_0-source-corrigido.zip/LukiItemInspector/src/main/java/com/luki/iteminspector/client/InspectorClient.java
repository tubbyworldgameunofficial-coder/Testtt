package com.luki.iteminspector.client;

import com.luki.iteminspector.LukiItemInspector;
import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = LukiItemInspector.MOD_ID, value = Dist.CLIENT,
        bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class InspectorClient {
    public static final KeyMapping INSPECT = new KeyMapping(
            "key.lukiiteminspector.inspect", KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, "key.categories.lukiiteminspector");

    private static boolean inspecting;
    private static boolean frozen;
    private static float frozenYaw, frozenPitch;
    // alvos (atualizados por tick) e valores suavizados (atualizados por frame)
    private static float targetYaw, targetPitch, targetZoom;
    private static float curYaw, curPitch, curZoom;
    private static float inspectProgress, previousInspectProgress;
    private static long lastFrameNanos;

    private InspectorClient() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        // START: a rotação do jogador é restaurada ANTES do tick do jogador,
        // então nenhum pacote de movimento carrega a rotação do mouse.
        if (event.phase != TickEvent.Phase.START) return;
        Minecraft mc = Minecraft.getInstance();
        previousInspectProgress = inspectProgress;
        if (mc.player == null || mc.level == null) {
            inspecting = false;
            frozen = false;
            inspectProgress = previousInspectProgress = 0.0F;
            return;
        }
        while (INSPECT.consumeClick()) {
            if (inspecting) {
                inspecting = false;
            } else if (!mc.player.isSpectator() && !mc.player.isUsingItem() && !mc.player.isPassenger()
                    && mc.screen == null) {
                inspecting = true;
                frozen = false;
                targetYaw = targetPitch = targetZoom = 0.0F;
                curYaw = curPitch = curZoom = 0.0F;
            }
        }
        if (mc.screen != null || mc.player.isUsingItem() || mc.player.isPassenger()) inspecting = false;

        float target = inspecting ? 1.0F : 0.0F;
        inspectProgress += (target - inspectProgress) * 0.35F;
        if (Math.abs(target - inspectProgress) < 0.002F) inspectProgress = target;

        if (!inspecting) {
            frozen = false;
            return;
        }
        if (!frozen) {
            frozenYaw = mc.player.getYRot();
            frozenPitch = mc.player.getXRot();
            frozen = true;
            return;
        }
        float dYaw = Mth.wrapDegrees(mc.player.getYRot() - frozenYaw);
        float dPitch = mc.player.getXRot() - frozenPitch;
        targetYaw = Mth.wrapDegrees(targetYaw + dYaw * 1.7F);
        targetPitch = Mth.clamp(targetPitch + dPitch * 1.7F, -89.0F, 89.0F);
        mc.player.setYRot(frozenYaw);
        mc.player.setXRot(frozenPitch);
        mc.player.yRotO = frozenYaw;
        mc.player.xRotO = frozenPitch;
    }

    /** Mantém a câmera parada entre ticks enquanto o mouse gira o item. */
    @SubscribeEvent
    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        if (!inspecting || !frozen) return;
        event.setYaw(frozenYaw);
        event.setPitch(frozenPitch);
    }

    @SubscribeEvent
    public static void onMouseScroll(InputEvent.MouseScrollingEvent event) {
        if (!inspecting) return;
        targetZoom = Mth.clamp(targetZoom + (float) event.getScrollDelta() * 0.05F, -0.30F, 0.45F);
        event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent event) {
        if (inspectProgress <= 0.01F && previousInspectProgress <= 0.01F) return;
        event.setCanceled(true); // cancela mão principal e secundária do vanilla
        if (event.getHand() != net.minecraft.world.InteractionHand.MAIN_HAND) return;
        Minecraft mc = Minecraft.getInstance();
        if (!(mc.player instanceof AbstractClientPlayer player) || mc.level == null) return;

        PoseStack pose = event.getPoseStack();
        MultiBufferSource buffers = event.getMultiBufferSource();
        int light = event.getPackedLight();
        float partial = event.getPartialTick();

        // suavização independente do framerate
        long now = System.nanoTime();
        float dt = lastFrameNanos == 0L ? 0.016F : Math.min(0.1F, (now - lastFrameNanos) / 1.0E9F);
        lastFrameNanos = now;
        float k = 1.0F - (float) Math.exp(-dt * 14.0F);
        curYaw += Mth.wrapDegrees(targetYaw - curYaw) * k;
        curPitch += (targetPitch - curPitch) * k;
        curZoom += (targetZoom - curZoom) * k;

        float progress = Mth.lerp(partial, previousInspectProgress, inspectProgress);
        float eased = progress * progress * (3.0F - 2.0F * progress);

        if (mc.getEntityRenderDispatcher().getRenderer(player) instanceof PlayerRenderer renderer) {
            renderArm(pose, buffers, light, player, renderer, HumanoidArm.RIGHT, eased);
            renderArm(pose, buffers, light, player, renderer, HumanoidArm.LEFT, eased);
        }

        ItemStack held = player.getMainHandItem();
        if (held.isEmpty()) held = player.getOffhandItem();
        if (held.isEmpty()) return;

        pose.pushPose();
        pose.translate(0.0D, -0.10D * eased, -0.62D * eased - 0.30D * (1.0F - eased) + curZoom * eased);
        pose.mulPose(Axis.XP.rotationDegrees(curPitch * eased));
        pose.mulPose(Axis.YP.rotationDegrees(curYaw * eased));
        float scale = 0.9F + 0.35F * eased;
        pose.scale(scale, scale, scale);
        // renderStatic usa o modelo baked + renderer do item: compatível com itens de outros mods
        mc.getItemRenderer().renderStatic(player, held, ItemDisplayContext.FIXED, false,
                pose, buffers, mc.level, light, OverlayTexture.NO_OVERLAY, player.getId());
        pose.popPose();
    }

    /** Mesma cadeia de transformações do ItemInHandRenderer.renderPlayerArm, com braços convergindo ao item. */
    private static void renderArm(PoseStack pose, MultiBufferSource buffers, int light,
                                  AbstractClientPlayer player, PlayerRenderer renderer,
                                  HumanoidArm arm, float eased) {
        float f = arm == HumanoidArm.RIGHT ? 1.0F : -1.0F;
        float hidden = 1.0F - eased; // 1 = abaixo da tela, 0 = posição de inspeção
        pose.pushPose();
        pose.translate(f * (0.64F - 0.20F * eased), -0.6F - 0.6F * hidden + 0.05F * eased, -0.72F);
        pose.mulPose(Axis.YP.rotationDegrees(f * (45.0F - 22.0F * eased)));
        pose.translate(f * -1.0F, 3.6F, 3.5F);
        pose.mulPose(Axis.ZP.rotationDegrees(f * 120.0F));
        pose.mulPose(Axis.XP.rotationDegrees(200.0F));
        pose.mulPose(Axis.YP.rotationDegrees(f * -135.0F));
        pose.translate(f * 5.6F, 0.0F, 0.0F);
        if (arm == HumanoidArm.RIGHT) renderer.renderRightHand(pose, buffers, light, player);
        else renderer.renderLeftHand(pose, buffers, light, player);
        pose.popPose();
    }
}
